<?php

namespace App\PostType;


class PostTypeIcon
{
    public function iconList(){

        return[
          '<i data-feather="activity"></i>',
          '<i data-feather="airplay"></i>'
        ];

    }
}